import { UploadButton } from "../lib/UploadButton";

export function App() {
    return (
        <>
            <UploadButton></UploadButton>
        </>
    );
}
