export default function DefaultNav() {
    return <div>Dashboard</div>;
}
