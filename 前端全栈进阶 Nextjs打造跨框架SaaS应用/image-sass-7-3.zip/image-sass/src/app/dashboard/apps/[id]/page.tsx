"use client";

import { Uppy } from "@uppy/core";
import AWSS3 from "@uppy/aws-s3";
import { useState } from "react";
import { trpcPureClient } from "@/utils/api";
import { Button } from "@/components/ui/Button";
import { UploadButton } from "@/components/feature/UploadButton";
import { Dropzone } from "@/components/feature/Dropzone";
import { usePasteFile } from "@/hooks/usePasteFile";
import { UploadPreview } from "@/components/feature/UploadPreview";
import { FileList } from "@/components/feature/FileList";
import { FilesOrderByColumn } from "@/server/routes/file";
import { MoveUp, MoveDown, Settings } from "lucide-react";
import Link from "next/link";

export default function AppPage({
    params: { id: appId },
}: {
    params: { id: string };
}) {
    const [uppy] = useState(() => {
        const uppy = new Uppy();
        uppy.use(AWSS3, {
            shouldUseMultipart: false,
            getUploadParameters(file) {
                return trpcPureClient.file.createPresignedUrl.mutate({
                    filename:
                        file.data instanceof File ? file.data.name : "test",
                    contentType: file.data.type || "",
                    size: file.size,
                    appId: appId,
                });
            },
        });
        return uppy;
    });

    usePasteFile({
        onFilesPaste: (files) => {
            uppy.addFiles(
                files.map((file) => ({
                    data: file,
                }))
            );
        },
    });

    const [orderBy, setOrderBy] = useState<
        Exclude<FilesOrderByColumn, undefined>
    >({
        field: "createdAt",
        order: "desc",
    });

    return (
        <div className="mx-auto h-full">
            <div className="container flex justify-between items-center h-[60px]">
                <Button
                    onClick={() => {
                        setOrderBy((current) => ({
                            ...current,
                            order: current?.order === "asc" ? "desc" : "asc",
                        }));
                    }}
                >
                    Created At{" "}
                    {orderBy.order === "desc" ? <MoveUp /> : <MoveDown />}
                </Button>
                <div className="flex justify-center gap-2">
                    <UploadButton uppy={uppy}></UploadButton>
                    <Button asChild>
                        <Link href="./new">new app</Link>
                    </Button>
                    <Button asChild>
                        <Link href={`/dashboard/apps/${appId}/setting/storage`}>
                            <Settings></Settings>
                        </Link>
                    </Button>
                </div>
            </div>

            <Dropzone uppy={uppy} className=" relative h-[calc(100%-60px)]">
                {(draging) => {
                    return (
                        <>
                            {draging && (
                                <div className=" absolute inset-0 bg-secondary/50 z-10 flex justify-center items-center text-3xl">
                                    Drop File Here to Upload
                                </div>
                            )}
                            <FileList
                                appId={appId}
                                uppy={uppy}
                                orderBy={orderBy}
                            ></FileList>
                        </>
                    );
                }}
            </Dropzone>
            <UploadPreview uppy={uppy}></UploadPreview>
        </div>
    );
}
