<template>
    <div>
        <VueUploadButton> asdasd </VueUploadButton>
    </div>
</template>

<script setup>
import { createApiClient } from "@image-sass/api";
import { onMounted, ref, watchEffect } from "vue";
import { UploadButton } from "@image-saas/upload-button";
import { connect } from "@image-saas/preact-vue-connect";

const VueUploadButton = connect(UploadButton);

onMounted(async () => {
    const tokenResp = await fetch("/api/test");
    const token = await tokenResp.text();

    const apiClient = createApiClient({ signedToken: token });

    apiClient.file.createPresignedUrl.mutate({
        filename: "Screenshot 2023-06-20 200151.png",
        contentType: "image/png",
        size: 34105,
        appId: "c52963e1-dfa2-4e70-8333-04de2dcbbb4b",
    });
});
</script>
