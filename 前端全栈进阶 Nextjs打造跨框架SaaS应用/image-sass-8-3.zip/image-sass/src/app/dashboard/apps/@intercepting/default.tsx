export default function DefaultIntercepting() {
    return null;
}
