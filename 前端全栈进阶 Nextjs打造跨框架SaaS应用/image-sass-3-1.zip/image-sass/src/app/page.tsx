export default function Home() {
    return <div>Root Page</div>;
}
