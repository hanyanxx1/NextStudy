import { UploadButton } from "../lib/Dropzone";

export function App() {
    return (
        <>
            <UploadButton></UploadButton>
        </>
    );
}
