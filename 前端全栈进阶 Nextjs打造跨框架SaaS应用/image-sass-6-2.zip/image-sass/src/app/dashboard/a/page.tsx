export default function PageA() {
    return <div>AAA</div>;
}
