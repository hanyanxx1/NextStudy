export default function NavA() {
    return <div>AAA</div>;
}
