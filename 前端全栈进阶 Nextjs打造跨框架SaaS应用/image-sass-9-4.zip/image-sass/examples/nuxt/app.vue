<template>
    <div>
        <Index />
    </div>
</template>

<script setup>
import Index from "./app/Index.vue";
</script>
