import { createApiClient } from "@image-sass/api";

const apiKey = "92255a3e-dc47-40f2-b06e-266a117b3a0a";

export default defineEventHandler(async (event) => {
    // console.log(apiClient);

    const apiClient = createApiClient({ apiKey });

    const response = await apiClient.file.createPresignedUrl.mutate({
        filename: "Screenshot 2023-06-20 200151.png",
        contentType: "image/png",
        size: 34105,
        appId: "c52963e1-dfa2-4e70-8333-04de2dcbbb4b",
    });

    return response;
});
